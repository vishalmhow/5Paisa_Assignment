//
//  PSchemeCell.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 19/02/22.
//

import UIKit

class PSchemeCell: UITableViewCell {
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var schemeNameLabel: UILabel!
    @IBOutlet weak var riskometerLabel: UILabel!
    @IBOutlet weak var navLabel: UILabel!
    @IBOutlet weak var recommendedLabel: UILabel!
    @IBOutlet weak var changeLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
//        bgView.layer.shadowColor = UIColor.black.cgColor
//        bgView.layer.shadowOpacity = 1
//        bgView.layer.shadowOffset = .zero
//        bgView.layer.shadowRadius = 10
        // Initialization code
        
        
        bgView.layer.shadowColor = UIColor.black.cgColor
        bgView.layer.shadowOffset = .zero
        bgView.layer.shadowOpacity = 0.7
        bgView.layer.shadowRadius = 7
        
        bgView.layer.cornerRadius = 10.0
//        bgView.layer.borderColor = UIColor.gray.cgColor
//        bgView.layer.borderWidth = 0.5
     //   bgView.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureSummary(schemeModel: SchemesEntity) {
        schemeNameLabel.text = schemeModel.schemeName
        riskometerLabel.text = schemeModel.riskometervalue
        navLabel.text = schemeModel.nav
        recommendedLabel.text = schemeModel.recommenedFundFlag
        changeLabel.text = schemeModel.perChange
    }

}
