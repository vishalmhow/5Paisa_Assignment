//
//  Constants.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 23/02/22.
//

import Foundation
class Constants {
    enum SortType {
        case sun, cloud, rain, wind, snow
    }
}

//    Sort: NAV (desc), PerChange(desc),  AUM(desc) - one at a time

