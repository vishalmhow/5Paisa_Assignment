//
//  PDashboardContainerVC.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 21/02/22.
//

import Foundation
import UIKit

class PDashboardContainerVC: UIViewController  {
    var timer = Timer()
    var viewModel = PDashboardContainerViewModel()
    
    @IBOutlet weak var menuBarView: PSlideTabView!
    
    var currentIndex: Int = 0
    var tabs = ["All", "Direct", "Regular"]
    var pageController: UIPageViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(tabs)
        
        self.title = "Schems"
        let filterButton = UIBarButtonItem(title: "Filter", style: .plain, target: self, action: #selector(filterButtonTapped))
        self.navigationItem.leftBarButtonItem = filterButton
        let logoutButton = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(logoutButtonTapped))
        self.navigationItem.rightBarButtonItem = logoutButton
        navigationItem.rightBarButtonItem?.setTitleTextAttributes([.font : UIFont.systemFont(ofSize: 17, weight: .bold), .foregroundColor : UIColor(red: 139/255, green: 26/255, blue: 56/255, alpha: 1)], for: .normal)
        navigationItem.leftBarButtonItem?.setTitleTextAttributes([.font : UIFont.systemFont(ofSize: 17, weight: .bold), .foregroundColor : UIColor(red: 139/255, green: 26/255, blue: 56/255, alpha: 1)], for: .normal)
        
        let textAttributes = [NSAttributedString.Key.foregroundColor:UIColor(red: 139/255, green: 26/255, blue: 56/255, alpha: 1)]
        navigationController?.navigationBar.titleTextAttributes = textAttributes
        
        self.fetchSchemes()
        
    }
    func fetchSchemes() {
        self.viewModel.fetchSchemes { status in
            if status {
                DispatchQueue.main.async {
                    //                    self.schemeTableView.reloadData()
                    self.menuBarView.dataArray = self.tabs
                    self.menuBarView.isSizeToFitCellsNeeded = true
                    //  self.menuBarView.collView.backgroundColor = UIColor.init(white: 0.97, alpha: 0.97)
                    
                    self.presentPageVCOnView()
                    
                    self.menuBarView.menuDelegate = self
                    self.pageController.delegate = self
                    self.pageController.dataSource = self
                    
                    //For Intial Display
                    self.menuBarView.collView.selectItem(at: IndexPath.init(item: 0, section: 0), animated: true, scrollPosition: .centeredVertically)
                    self.pageController.setViewControllers([self.viewController(At: 0)!], direction: .forward, animated: true, completion: nil)
                }
            }
        }
    }
    @objc func refreshSchemes(_ sender: AnyObject) {
        // Code to refresh table view
        //        self.timer.invalidate()
        //        self.viewModel.schaduledToFetchSchemes(isSchaduled: true) { status in
        //            DispatchQueue.main.async {
        //                self.refreshControl.endRefreshing()
        //                self.schemeTableView.reloadData()
        //            }
        //        }
        //        self.timer = Timer.scheduledTimer(withTimeInterval: 1800, repeats: true, block: { _ in
        //            self.viewModel.schaduledToFetchSchemes(isSchaduled: true) { status in
        //                DispatchQueue.main.async {
        //                    self.refreshControl.endRefreshing()
        //                    self.schemeTableView.reloadData()
        //                }
        //            }
        //        })
    }
    
    
    @objc func filterButtonTapped() {
        let alert = UIAlertController(title: "Sort & Filter", message: "Please Select an Option", preferredStyle: .actionSheet)
        
        if !(self.viewModel.selectedSort?.rawValue.isEmpty ?? true) || !self.viewModel.selectedFilters.isEmpty {
            alert.addAction(UIAlertAction(title: "Clear all Filters", style: .default , handler:{ (UIAlertAction)in
                self.clearAllFilters()
            }))
        }
        alert.addAction(UIAlertAction(title: "Sort & Filter", style: .default , handler:{ (UIAlertAction)in
            self.openFilterController()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .destructive , handler:{ (UIAlertAction)in
        }))
        self.present(alert, animated: true, completion: {
            print("completion block")
        })
    }
    
    func clearAllFilters() {
        self.viewModel.selectedFilters.removeAll()
        self.viewModel.selectedSort = nil
        self.viewModel.fetchSchemes { status in
            NotificationCenter.default.post(name: Notification.Name("NotificationIdentifier"), object: [self.viewModel.dataArray,self.viewModel.dataArray1,self.viewModel.dataArray2])
            
        }
    }
    
    func openFilterController() {
        guard let filterController = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "PFilterController") as? PFilterController else {
            return
        }
        filterController.delegate = self
        self.navigationController?.pushViewController(filterController, animated: false)
    }
    
    @objc func logoutButtonTapped() {
        self.timer.invalidate()
        self.navigationController?.popViewController(animated: false)
    }
    
    /*
     // Call back function
     func myLocalFunc(_ collectionView: UICollectionView, _ indexPath: IndexPath) {
     
     
     if indexPath.item != currentIndex {
     
     if indexPath.item > currentIndex {
     self.pageController.setViewControllers([viewController(At: indexPath.item)!], direction: .forward, animated: true, completion: nil)
     }else {
     self.pageController.setViewControllers([viewController(At: indexPath.item)!], direction: .reverse, animated: true, completion: nil)
     }
     
     menuBarView.collView.scrollToItem(at: IndexPath.init(item: indexPath.item, section: 0), at: .centeredHorizontally, animated: true)
     
     }
     }
     */
    
    func presentPageVCOnView() {
        
        self.pageController = storyboard?.instantiateViewController(withIdentifier: "PageControllerVC") as! PageControllerVC
        self.pageController.view.frame = CGRect.init(x: 0, y: menuBarView.frame.maxY, width: self.view.frame.width, height: self.view.frame.height - menuBarView.frame.maxY)
        self.addChild(self.pageController)
        self.view.addSubview(self.pageController.view)
        self.pageController.didMove(toParent: self)
        
    }
    
    //Present ViewController At The Given Index
    
    func viewController(At index: Int) -> UIViewController? {
        
        if((self.menuBarView.dataArray.count == 0) || (index >= self.menuBarView.dataArray.count)) {
            return nil
        }
        
        let allVC = storyboard?.instantiateViewController(withIdentifier: "PDashboardViewController") as! PDashboardViewController
        allVC.viewModel.pageIndex = index
        
        switch index {
        case 0:
            allVC.viewModel.dataArray = self.viewModel.dataArray
            return allVC
        case 1:
            allVC.viewModel.dataArray1 = self.viewModel.dataArray1
            return allVC
        case 2:
            allVC.viewModel.dataArray2 = self.viewModel.dataArray2
            return allVC
        default:
            allVC.viewModel.dataArray = self.viewModel.dataArray
            return allVC
        }
    }
}

extension PDashboardContainerVC: MenuBarDelegate {
    
    func menuBarDidSelectItemAt(menu: PSlideTabView, index: Int) {
        if index != currentIndex {
            if index > currentIndex {
                self.pageController.setViewControllers([viewController(At: index)!], direction: .forward, animated: true, completion: nil)
            }else {
                self.pageController.setViewControllers([viewController(At: index)!], direction: .reverse, animated: true, completion: nil)
            }
            menuBarView.collView.scrollToItem(at: IndexPath.init(item: index, section: 0), at: .centeredHorizontally, animated: true)
        }
    }
    
}


extension PDashboardContainerVC: UIPageViewControllerDataSource, UIPageViewControllerDelegate {
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        var index = (viewController as! PDashboardViewController).viewModel.pageIndex
        
        if (index == 0) || (index == NSNotFound) {
            return nil
        }
        index -= 1
        return self.viewController(At: index)
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        var index = (viewController as! PDashboardViewController).viewModel.pageIndex
        
        if (index == tabs.count) || (index == NSNotFound) {
            return nil
        }
        index += 1
        return self.viewController(At: index)
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        
        if finished {
            if completed {
                
                let cvc = pageViewController.viewControllers!.first as! PDashboardViewController
                let newIndex = cvc.viewModel.pageIndex
                menuBarView.collView.selectItem(at: IndexPath.init(item: newIndex, section: 0), animated: true, scrollPosition: .centeredVertically)
                menuBarView.collView.scrollToItem(at: IndexPath.init(item: newIndex, section: 0), at: .centeredHorizontally, animated: true)
            }
        }
    }
}

extension PDashboardContainerVC: PFilterControllerDelegate {
    func applyFilterAndSort(_ filterArray: [SchemsFilter], sort: SchemsSort?) {
        
        switch sort {
        case .nav:
            print("NAV")
        case .perChange:
            print("perChange")
        case .aum:
            print("aum")
        default:
            print("NAV")
        }
        
        if sort?.rawValue.isEmpty ?? true && filterArray.isEmpty {
            return
        }
        self.viewModel.selectedFilters = filterArray
        self.viewModel.selectedSort = sort
        self.viewModel.filterAndSortData(filterArray, sort: sort) { status in
        }
    }
}
