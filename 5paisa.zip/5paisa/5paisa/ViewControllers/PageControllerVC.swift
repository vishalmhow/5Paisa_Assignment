//
//  PageControllerVC.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 22/02/22.
//

import UIKit

class PageControllerVC: UIPageViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
