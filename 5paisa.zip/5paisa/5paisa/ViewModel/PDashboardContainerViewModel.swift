//
//  PDashboardViewModel.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 19/02/22.
//

import Foundation
import CoreData

enum SchemsSort: String {
    case nav = "NAV (desc)"
    case perChange = "PerChange(desc)"
    case aum = "AUM(desc)"
}

enum SchemsFilter: String {
    case riskometer = "Riskometer value"
    case recommendedFund = "Recommended Fund Flag"
}

class PDashboardContainerViewModel: NSObject {
    
    let repository = PWebServiceManager(apiClient: APIClient())
    var markedVitalArray: SchemesResponseModel?
    let persistence = PPersistenceService.shared
    var schemeList = [SchemesEntity]()
    var selectedFilters = [SchemsFilter]()
    var selectedSort: SchemsSort?
    
    var dataArray = [SchemesEntity]()
    var dataArray1 = [SchemesEntity]()
    var dataArray2 = [SchemesEntity]()
    
    
    func getSchemeList(completion: @escaping((Bool) -> Void)) {
        repository.getSchemes { response in
            self.markedVitalArray = response
            self.persistence.removeAllData("SchemesEntity")
            self.saveSchemes(schemeData: self.markedVitalArray?.response.data.schemelist.scheme ?? []) { _ in
                completion(true)
            }
        } failure: { error in
            print(error!)
        }
    }
    
    func saveSchemes(schemeData: [SchemeData], completion: @escaping((Bool) -> Void)) {
        if schemeData.isEmpty {
            return
        }
        _ = schemeData.compactMap { obj -> SchemesEntity in
            let aum = obj.aum
            let amccode = obj.amccode
            let mfSchcode = obj.mfSchcode
            let schemeName = obj.schemeName
            let mainCode = obj.mainCode
            let schemeCategory = obj.schemeCategory
            let oneYear = obj.oneYear
            let threeYear = obj.threeYear
            let fiveYear = obj.fiveYear
            let inception = obj.inception
            let nav = obj.nav
            let perChange = obj.perChange
            let riskometervalue = obj.riskometervalue
            let recommenedFundFlag = obj.recommenedFundFlag
            let morningstaroverall = obj.morningstaroverall
            let subscriptionFlag = obj.subscriptionFlag
            let investment = obj.investment
            let groupCode = obj.groupCode
            let isin = obj.isin
            
            let scheme = SchemesEntity(context: self.persistence.context)
            scheme.aum = aum
            scheme.amccode = amccode
            scheme.fiveYear = fiveYear
            scheme.groupCode = groupCode
            scheme.inception = inception
            scheme.investment = investment
            scheme.isin = isin
            scheme.mainCode = mainCode
            scheme.mf_schcode = mfSchcode
            scheme.morningstaroverall = morningstaroverall
            scheme.nav = nav
            scheme.oneYear = oneYear
            scheme.perChange = perChange
            scheme.recommenedFundFlag = recommenedFundFlag
            scheme.riskometervalue = riskometervalue
            scheme.schemeCategory = schemeCategory
            scheme.schemeName = schemeName
            scheme.subscriptionFlag = subscriptionFlag
            scheme.threeYear = threeYear
            return scheme
        }
        self.persistence.save()
        completion(true)
    }
    
    func fetchSchemes(completion: @escaping((Bool) -> Void)) {
        if self.dataArray.isEmpty {
            self.getSchemeList { status in
                if status {
                    self.persistence.fetchData(SchemesEntity.self) { (schemeList) in
                        // self.schemeList = []
                        //  self.schemeList = schemeList
                        //                        "investment": "Direct Plan"  -> Direct
                        //                        "investment": "InDirect Plan" -> Regular
                        
                        self.dataArray = schemeList
                        self.dataArray1 = schemeList.filter { $0.investment == "Direct Plan" }
                        self.dataArray2 = schemeList.filter { $0.investment == "InDirect Plan" }
                        // self.dataArray1 = schemeList
                        // self.dataArray2 = schemeList
                        completion(true)
                    }
                }
            }
        } else {
            self.persistence.fetchData(SchemesEntity.self) { (schemeList) in
                self.schemeList = []
                self.schemeList = schemeList
                completion(true)
            }
        }
        
    }
    func schaduledToFetchSchemes(isSchaduled: Bool, completion: @escaping((Bool) -> Void)) {
        
        self.persistence.fetchData(SchemesEntity.self) { (schemeList) in
            self.schemeList = []
            self.schemeList = schemeList
            completion(true)
        }
        if self.schemeList.isEmpty {
            self.getSchemeList { status in
                if status {
                    self.persistence.fetchData(SchemesEntity.self) { (schemeList) in
                        self.schemeList = []
                        self.schemeList = schemeList
                        completion(true)
                    }
                }
            }
        }
    }
    func filterAndSortData(_ filterArray: [SchemsFilter], sort: SchemsSort?, completion: @escaping((Bool) -> Void)) {
        
        var filteredDataArray = [SchemesEntity]()
        var schemsToBeFiltered = [SchemesEntity]()
        schemsToBeFiltered = self.dataArray
        
        
        for index in filterArray {
            switch index {
            case .riskometer:
                filteredDataArray = schemsToBeFiltered.filter {$0.riskometervalue == "Very High"}
            case .recommendedFund:
                filteredDataArray = schemsToBeFiltered.filter {$0.recommenedFundFlag == "Y"}
            }
        }
        if !filteredDataArray.isEmpty {
            schemsToBeFiltered = filteredDataArray
        }
        
        switch sort {
        case .nav:
            filteredDataArray = schemsToBeFiltered.sorted(by: { $0.nav?.toDouble() ?? 0 > $1.nav?.toDouble() ?? 0 })
        case .perChange:
            filteredDataArray = schemsToBeFiltered.sorted(by: { $0.perChange?.toDouble() ?? 0 > $1.perChange?.toDouble() ?? 0 })
        case .aum:
            filteredDataArray = schemsToBeFiltered.sorted(by: { $0.aum?.toDouble() ?? 0 > $1.aum?.toDouble() ?? 0 })
        default:
            print("Nothing")
        }
        
        if !filteredDataArray.isEmpty {
            NotificationCenter.default.post(name: Notification.Name("NotificationIdentifier"), object: filteredDataArray)
        }
        
        
        completion(true)
        
    }
}
