//
//  PDashboardViewModel.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 25/02/22.
//

import Foundation

class PDashboardViewModel: NSObject {
    var pageIndex: Int = 0
    var dataArray = [SchemesEntity]()
    var dataArray1 = [SchemesEntity]()
    var dataArray2 = [SchemesEntity]()
    
    func formateFilteredData(notification: Notification, completion: @escaping((Bool) -> Void)) {
        if let arr = notification.object as? [SchemesEntity] {
            switch pageIndex {
            case 0:
                self.dataArray = arr
            case 1:
                self.dataArray1 = arr
            case 2:
                self.dataArray2 = arr
            default:
                print("Default")
            }
        }
        if let arr = notification.object as? [[SchemesEntity]] {
            self.dataArray = arr[0]
            self.dataArray1 = arr[1]
            self.dataArray2 = arr[2]
        }
        completion(true)
    }
}
